# Knapsack Algorithm Analyzer

A premium dark-themed dashboard for visualizing and comparing knapsack algorithms.

## Features

- **8 Pages**: Dashboard, Algorithm Visualizer, Benchmarking, Performance, Complexity, Greedy Analysis, Reports, Settings
- **4 Algorithms**: Dynamic Programming, Greedy, Backtracking, Branch & Bound
- **Auto Demo Mode**: One-click runs all algorithms with live narration
- **Item Editor**: 4 preset scenarios (Treasure Hunt, Hiking Gear, Tech Gadgets, Museum Heist) + full editing
- **Greedy Analysis**: Variant comparison, Fractional Knapsack, Real-world scenarios, Approximation ratios
- **VS Code Code Panel**: Live-highlighted algorithm code during animation
- **DP Table Visualization**: Watch the table fill in real-time

## Running Locally

### Requirements
- Node.js 18+ (download from https://nodejs.org)
- npm (comes with Node.js)

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev

# 3. Open in browser
# http://localhost:5173
```

### Build for production

```bash
npm run build
npm run preview
```

## Tech Stack

- React 19 + TypeScript
- Vite 7
- Tailwind CSS v4
- Framer Motion
- Recharts
- shadcn/ui components
- Wouter (routing)
