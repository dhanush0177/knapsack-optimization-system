import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useAppContext } from "@/contexts/AppContext";
import { Sun, Moon, Monitor, Zap, Table2, Layers } from "lucide-react";

export default function Settings() {
  const {
    theme, setTheme,
    animationSpeed, setAnimationSpeed,
    selectedAlgorithm, setSelectedAlgorithm,
    showDPTable, setShowDPTable,
    capacity, setCapacity,
    items, regenerateDataset,
  } = useAppContext();

  const speedValues: Record<string, number[]> = { slow: [1], medium: [2], fast: [3] };
  const reverseSpeed: Record<number, "slow" | "medium" | "fast"> = { 1: "slow", 2: "medium", 3: "fast" };

  return (
    <div className="space-y-6 max-w-2xl">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <h2 className="text-xl font-bold">Settings</h2>
        <p className="text-sm text-muted-foreground mt-1">Configure your algorithm analyzer preferences</p>
      </motion.div>

      {/* Appearance */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}>
        <Card className="glass-panel">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Sun className="w-4 h-4 text-primary" />
              Appearance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-sm mb-2 block">Theme</Label>
              <div className="flex gap-2">
                {[
                  { value: "dark", label: "Dark", icon: Moon },
                  { value: "light", label: "Light", icon: Sun },
                  { value: "system", label: "System", icon: Monitor },
                ].map(({ value, label, icon: Icon }) => (
                  <button
                    key={value}
                    onClick={() => setTheme(value as "dark" | "light" | "system")}
                    data-testid={`btn-theme-${value}`}
                    className={`flex-1 flex flex-col items-center gap-1.5 px-4 py-3 rounded-lg border text-sm transition-all duration-200 ${
                      theme === value
                        ? "border-primary/50 bg-primary/10 text-primary"
                        : "border-white/10 bg-white/3 text-muted-foreground hover:bg-white/5 hover:text-foreground"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Visualizer */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.13 }}>
        <Card className="glass-panel">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" />
              Visualizer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <Label className="text-sm mb-3 block">Animation Speed</Label>
              <Slider
                min={1}
                max={3}
                step={1}
                value={speedValues[animationSpeed]}
                onValueChange={(v) => setAnimationSpeed(reverseSpeed[v[0]])}
                className="w-full"
                data-testid="slider-animation-speed"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>Slow</span>
                <span className="font-medium text-primary capitalize">{animationSpeed}</span>
                <span>Fast</span>
              </div>
            </div>

            <div>
              <Label className="text-sm mb-2 block">Default Algorithm</Label>
              <Select value={selectedAlgorithm} onValueChange={(v) => setSelectedAlgorithm(v as typeof selectedAlgorithm)} data-testid="select-default-algorithm">
                <SelectTrigger className="w-full bg-muted/40 border-white/10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dp">Dynamic Programming</SelectItem>
                  <SelectItem value="greedy">Greedy</SelectItem>
                  <SelectItem value="backtracking">Backtracking</SelectItem>
                  <SelectItem value="branch-bound">Branch & Bound</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm">Show DP Table</Label>
                <p className="text-xs text-muted-foreground mt-0.5">Display dynamic programming table during visualization</p>
              </div>
              <Switch
                checked={showDPTable}
                onCheckedChange={setShowDPTable}
                data-testid="switch-show-dp-table"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Dataset */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}>
        <Card className="glass-panel">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Layers className="w-4 h-4 text-primary" />
              Dataset Defaults
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <Label className="text-sm mb-3 block">Default Capacity: <span className="font-mono text-primary">{capacity}</span></Label>
              <Slider
                min={10}
                max={200}
                step={5}
                value={[capacity]}
                onValueChange={(v) => setCapacity(v[0])}
                className="w-full"
                data-testid="slider-capacity"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>10</span>
                <span>200</span>
              </div>
            </div>

            <div>
              <Label className="text-sm mb-3 block">Default Items: <span className="font-mono text-primary">{items.length}</span></Label>
              <Slider
                min={3}
                max={20}
                step={1}
                value={[items.length]}
                onValueChange={(v) => regenerateDataset(v[0])}
                className="w-full"
                data-testid="slider-num-items"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>3</span>
                <span>20</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Display options */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.23 }}>
        <Card className="glass-panel">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Table2 className="w-4 h-4 text-primary" />
              Display
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { label: "Show step messages", sub: "Display algorithm step descriptions during visualization" },
              { label: "Highlight selected items", sub: "Highlight items chosen in the current solution" },
              { label: "Auto-run on load", sub: "Automatically run default algorithm when visualizer opens" },
            ].map((opt, i) => (
              <div key={i} className="flex items-center justify-between">
                <div>
                  <Label className="text-sm">{opt.label}</Label>
                  <p className="text-xs text-muted-foreground mt-0.5">{opt.sub}</p>
                </div>
                <Switch defaultChecked={i === 0} data-testid={`switch-opt-${i}`} />
              </div>
            ))}
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
        <p className="text-xs text-muted-foreground text-center">Knapsack Algorithm Analyzer — DAA Mini Project</p>
      </motion.div>
    </div>
  );
}
