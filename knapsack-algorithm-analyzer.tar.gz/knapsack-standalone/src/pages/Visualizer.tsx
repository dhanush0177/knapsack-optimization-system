import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, Pause, RotateCcw, SkipForward, SkipBack, Shuffle, ChevronRight, Code2, Pencil, Presentation, XCircle, ChevronDown } from "lucide-react";
import { ItemEditor } from "@/components/ItemEditor";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useAppContext } from "@/contexts/AppContext";
import { runDP, runGreedy, runBacktracking, runBranchAndBound, KnapsackResult, Step } from "@/lib/algorithms";
import { cn } from "@/lib/utils";
import { CodePanel } from "@/components/CodePanel";
import { ALGORITHM_CODE } from "@/lib/algorithmCode";

const ALGO_COLORS: Record<string, string> = {
  dp: "hsl(263, 90%, 65%)",
  greedy: "hsl(190, 100%, 50%)",
  backtracking: "hsl(45, 93%, 58%)",
  "branch-bound": "hsl(213, 100%, 60%)",
};

const SPEED_MS: Record<string, number> = { slow: 600, medium: 220, fast: 60 };

type AlgoType = 'dp' | 'greedy' | 'backtracking' | 'branch-bound';
const DEMO_ALGOS: AlgoType[] = ['dp', 'greedy', 'backtracking', 'branch-bound'];
const DEMO_NARRATIONS: Record<AlgoType, { title: string; text: string; color: string }> = {
  dp: {
    title: 'Dynamic Programming',
    color: 'hsl(263,90%,65%)',
    text: 'DP builds a table of sub-problem solutions bottom-up. For each item and each possible capacity, it asks: should I include this item? It fills every cell until the optimal answer emerges — guaranteed correct.',
  },
  greedy: {
    title: 'Greedy Algorithm',
    color: 'hsl(190,100%,50%)',
    text: 'Greedy ranks items by value÷weight ratio — the "bang for your buck" score — then grabs the best-ratio items first. Blazingly fast, but it can miss the true optimal when items don\'t combine perfectly.',
  },
  backtracking: {
    title: 'Backtracking',
    color: 'hsl(45,93%,58%)',
    text: 'Backtracking explores every possible combination like a decision tree. Include this item? Try both branches. When a path can\'t fit more items, it backtracks. Slow on large inputs, but provably correct.',
  },
  'branch-bound': {
    title: 'Branch & Bound',
    color: 'hsl(213,100%,60%)',
    text: 'Branch & Bound is intelligent backtracking. Before exploring a branch, it calculates a theoretical upper bound. If that bound can\'t beat the current best, the entire branch is pruned — dramatically faster!',
  },
};

const ITEM_COLORS = [
  "from-violet-500 to-purple-600",
  "from-cyan-500 to-blue-600",
  "from-amber-500 to-orange-600",
  "from-emerald-500 to-green-600",
  "from-rose-500 to-pink-600",
  "from-indigo-500 to-blue-700",
  "from-teal-500 to-cyan-700",
  "from-fuchsia-500 to-purple-700",
];

export default function Visualizer() {
  const { items, setItems, capacity, setCapacity, selectedAlgorithm, setSelectedAlgorithm, animationSpeed, setAnimationSpeed, addRunHistory, showDPTable, regenerateDataset } = useAppContext();

  const [result, setResult] = useState<KnapsackResult | null>(null);
  const [currentStep, setCurrentStep] = useState(-1);
  const [playing, setPlaying] = useState(false);
  const [numItems, setNumItems] = useState(items.length);
  const [showCode, setShowCode] = useState(false);
  const [showItemEditor, setShowItemEditor] = useState(false);
  const [demoMode, setDemoMode] = useState(false);
  const [demoIdx, setDemoIdx] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const demoTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const runAlgorithm = useCallback((alg = selectedAlgorithm) => {
    let res: KnapsackResult;
    if (alg === "dp") res = runDP(items, capacity);
    else if (alg === "greedy") res = runGreedy(items, capacity);
    else if (alg === "backtracking") res = runBacktracking(items, capacity);
    else res = runBranchAndBound(items, capacity);
    setResult(res);
    setCurrentStep(-1);
    setPlaying(false);
    addRunHistory({
      id: Date.now().toString(),
      timestamp: new Date(),
      capacity,
      numItems: items.length,
      algorithm: alg,
      result: res,
    });
  }, [items, capacity, selectedAlgorithm, addRunHistory]);

  const stopInterval = useCallback(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);
  }, []);

  useEffect(() => {
    if (!playing || !result) return;
    stopInterval();
    intervalRef.current = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev >= result.steps.length - 1) {
          setPlaying(false);
          return prev;
        }
        return prev + 1;
      });
    }, SPEED_MS[animationSpeed]);
    return stopInterval;
  }, [playing, result, animationSpeed, stopInterval]);

  const handleStart = () => {
    if (!result) runAlgorithm();
    if (result && currentStep >= result.steps.length - 1) setCurrentStep(-1);
    setPlaying(true);
  };

  const handlePause = () => setPlaying(false);

  const handleReset = () => {
    setPlaying(false);
    setCurrentStep(-1);
  };

  const handleStepForward = () => {
    if (!result) return;
    setCurrentStep((p) => Math.min(p + 1, result.steps.length - 1));
  };

  const handleStepBack = () => {
    setCurrentStep((p) => Math.max(p - 1, -1));
  };

  const handleGenerate = () => {
    regenerateDataset(numItems);
    setResult(null);
    setCurrentStep(-1);
    setPlaying(false);
  };

  // ── Demo mode ──────────────────────────────────────────────────────────────
  const stopDemo = useCallback(() => {
    setDemoMode(false);
    setPlaying(false);
    if (demoTimeoutRef.current) clearTimeout(demoTimeoutRef.current);
  }, []);

  const startDemo = useCallback(() => {
    setAnimationSpeed('medium');
    setDemoMode(true);
    setDemoIdx(0);
  }, [setAnimationSpeed]);

  // When demoIdx changes while demo is active, run that algorithm
  useEffect(() => {
    if (!demoMode) return;
    const algo = DEMO_ALGOS[demoIdx];
    setSelectedAlgorithm(algo);
    runAlgorithm(algo);
    demoTimeoutRef.current = setTimeout(() => setPlaying(true), 400);
    return () => { if (demoTimeoutRef.current) clearTimeout(demoTimeoutRef.current); };
  }, [demoIdx, demoMode]); // eslint-disable-line react-hooks/exhaustive-deps

  // When playing stops at the last step during demo, advance
  useEffect(() => {
    if (!demoMode || playing || !result) return;
    if (currentStep < result.steps.length - 1) return;
    demoTimeoutRef.current = setTimeout(() => {
      const next = demoIdx + 1;
      if (next < DEMO_ALGOS.length) {
        setDemoIdx(next);
      } else {
        setDemoMode(false);
      }
    }, 3200);
    return () => { if (demoTimeoutRef.current) clearTimeout(demoTimeoutRef.current); };
  }, [playing, demoMode, result, currentStep, demoIdx]);

  const currentStepData: Step | null = result && currentStep >= 0 ? result.steps[currentStep] ?? null : null;

  // Determine which items are selected at this step
  const selectedAtStep = result && currentStep >= 0
    ? (() => {
        const selected = new Set<number>();
        for (let i = 0; i <= currentStep; i++) {
          const s = result.steps[i];
          if (s.type === "select-item" && s.itemIndex !== undefined) {
            selected.add(s.itemIndex - 1);
          }
        }
        return selected;
      })()
    : new Set<number>(result?.selectedItems.map((id) => items.findIndex((it) => it.id === id)) ?? []);

  // Final selection (after algo runs)
  const finalSelected = result
    ? new Set<number>(result.selectedItems.map((id) => items.findIndex((it) => it.id === id)))
    : new Set<number>();

  const displaySelected = currentStep >= 0 ? selectedAtStep : finalSelected;

  const totalWeight = [...displaySelected].reduce((sum, i) => sum + (items[i]?.weight ?? 0), 0);
  const totalValue = [...displaySelected].reduce((sum, i) => sum + (items[i]?.value ?? 0), 0);
  const fillPct = capacity > 0 ? Math.min((totalWeight / capacity) * 100, 100) : 0;

  // DP table highlighting
  const dpHighlightCell = currentStepData?.type === "fill-cell" ? { row: currentStepData.itemIndex, col: currentStepData.capacity } : null;

  // DP table (only first 8 cols and all rows for display)
  const dpTableCols = Math.min(capacity, 15);

  return (
    <div className="space-y-5">
      {/* Controls row */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="glass-panel">
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center gap-4">
              {/* Algorithm select */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Algorithm</span>
                <Select
                  value={selectedAlgorithm}
                  onValueChange={(v) => { setSelectedAlgorithm(v as typeof selectedAlgorithm); setResult(null); setCurrentStep(-1); }}
                  data-testid="select-algorithm"
                >
                  <SelectTrigger className="w-44 bg-muted/40 border-white/10 h-9 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dp">Dynamic Programming</SelectItem>
                    <SelectItem value="greedy">Greedy</SelectItem>
                    <SelectItem value="backtracking">Backtracking</SelectItem>
                    <SelectItem value="branch-bound">Branch & Bound</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Capacity */}
              <div className="flex items-center gap-3 min-w-36">
                <span className="text-xs text-muted-foreground whitespace-nowrap">Capacity: <span className="font-mono text-foreground">{capacity}</span></span>
                <Slider min={10} max={100} step={5} value={[capacity]} onValueChange={(v) => setCapacity(v[0])} className="w-24" data-testid="slider-capacity" />
              </div>

              {/* Num items */}
              <div className="flex items-center gap-3 min-w-36">
                <span className="text-xs text-muted-foreground whitespace-nowrap">Items: <span className="font-mono text-foreground">{numItems}</span></span>
                <Slider min={3} max={15} step={1} value={[numItems]} onValueChange={(v) => setNumItems(v[0])} className="w-20" data-testid="slider-num-items" />
              </div>

              {/* Speed */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Speed</span>
                <Select value={animationSpeed} onValueChange={(v) => setAnimationSpeed(v as typeof animationSpeed)} data-testid="select-speed">
                  <SelectTrigger className="w-28 bg-muted/40 border-white/10 h-9 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="slow">Slow</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="fast">Fast</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-2 ml-auto flex-wrap">
                <Button variant="outline" onClick={() => setShowItemEditor(true)} className="border-white/10 hover:bg-white/5 h-9 text-xs gap-1.5" data-testid="btn-edit-items">
                  <Pencil className="w-3.5 h-3.5" />
                  Edit Items
                </Button>
                <Button variant="outline" onClick={handleGenerate} className="border-white/10 hover:bg-white/5 h-9 text-xs" data-testid="btn-generate">
                  <Shuffle className="w-3.5 h-3.5 mr-1.5" />
                  Randomize
                </Button>
                <Button
                  onClick={demoMode ? stopDemo : startDemo}
                  className={cn(
                    "h-9 text-xs gap-1.5",
                    demoMode
                      ? "bg-amber-500 hover:bg-amber-600 text-black"
                      : "bg-gradient-to-r from-violet-600 to-cyan-500 hover:opacity-90 text-white shadow-lg"
                  )}
                  data-testid="btn-demo"
                >
                  {demoMode ? <><XCircle className="w-3.5 h-3.5" />Stop Demo</> : <><Presentation className="w-3.5 h-3.5" />Auto Demo</>}
                </Button>
                <Button
                  variant={showCode ? "default" : "outline"}
                  onClick={() => setShowCode((v) => !v)}
                  className={cn(
                    "h-9 text-xs gap-1.5",
                    showCode ? "bg-primary hover:bg-primary/90 glow-primary" : "border-white/10 hover:bg-white/5"
                  )}
                  data-testid="btn-toggle-code"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  {showCode ? "Hide Code" : "Show Code"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Demo Mode narration banner */}
      <AnimatePresence>
        {demoMode && (
          <motion.div
            initial={{ opacity: 0, y: -16, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.97 }}
            transition={{ duration: 0.3 }}
            className="relative overflow-hidden rounded-xl border p-4"
            style={{ borderColor: DEMO_NARRATIONS[DEMO_ALGOS[demoIdx]].color + '44', background: DEMO_NARRATIONS[DEMO_ALGOS[demoIdx]].color + '12' }}
          >
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full blur-3xl opacity-20" style={{ background: DEMO_NARRATIONS[DEMO_ALGOS[demoIdx]].color }} />
            </div>
            <div className="relative z-10 flex items-start gap-4">
              <div className="flex flex-col items-center gap-2 shrink-0">
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white" style={{ background: DEMO_NARRATIONS[DEMO_ALGOS[demoIdx]].color }}>
                  {demoIdx + 1}
                </div>
                <div className="flex gap-1">
                  {DEMO_ALGOS.map((_, i) => (
                    <div key={i} className="w-1.5 h-1.5 rounded-full transition-all duration-300" style={{ background: i === demoIdx ? DEMO_NARRATIONS[DEMO_ALGOS[demoIdx]].color : 'rgba(255,255,255,0.15)' }} />
                  ))}
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold" style={{ color: DEMO_NARRATIONS[DEMO_ALGOS[demoIdx]].color }}>
                    Algorithm {demoIdx + 1} / {DEMO_ALGOS.length} — {DEMO_NARRATIONS[DEMO_ALGOS[demoIdx]].title}
                  </span>
                  {playing && <span className="flex items-center gap-1 text-[10px] text-muted-foreground animate-pulse"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />Running…</span>}
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{DEMO_NARRATIONS[DEMO_ALGOS[demoIdx]].text}</p>
              </div>
              <button onClick={stopDemo} className="shrink-0 p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-white/10 transition-colors">
                <XCircle className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main visualization area */}
      <div className={cn("gap-5", showCode ? "flex flex-col xl:flex-row" : "grid grid-cols-1 lg:grid-cols-3")}>
        {/* Left: Item table */}
        <motion.div
          layout
          initial={{ opacity: 0, x: -16 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className={showCode ? "xl:w-56 shrink-0" : ""}
        >
          <Card className="glass-panel h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs flex items-center gap-2">
                Items
                <Badge variant="secondary" className="text-xs">{items.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                {items.map((item, i) => {
                  const isSelected = displaySelected.has(i);
                  const isConsidering = currentStepData?.itemIndex === i + 1;
                  return (
                    <motion.div
                      key={item.id}
                      layout
                      className={cn(
                        "flex items-center gap-2 px-3 py-2 rounded-lg border transition-all duration-300 text-xs",
                        isSelected
                          ? "border-primary/40 bg-primary/10 text-foreground"
                          : isConsidering
                          ? "border-warning/40 bg-warning/10 text-foreground"
                          : "border-white/5 bg-white/2 text-muted-foreground"
                      )}
                      data-testid={`item-row-${item.id}`}
                    >
                      <div className={cn("w-2 h-2 rounded-full flex-shrink-0", ITEM_COLORS[i % ITEM_COLORS.length].split(" ")[0].replace("from-", "bg-"))} />
                      <span className="font-medium w-14 truncate">{item.name}</span>
                      <div className="flex gap-3 ml-auto font-mono">
                        <span className="text-muted-foreground">W:{item.weight}</span>
                        <span className="text-foreground font-semibold">V:{item.value}</span>
                        <span style={{ color: "hsl(190 100% 50%)" }}>{(item.value / item.weight).toFixed(1)}</span>
                      </div>
                      {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse ml-1" />}
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Middle: VS Code panel (when shown) */}
        <AnimatePresence>
          {showCode && (
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.25 }}
              className="flex-1 min-w-0"
              style={{ minHeight: 420 }}
            >
              <CodePanel
                codeDef={ALGORITHM_CODE[selectedAlgorithm]}
                activeLine={currentStepData ? ALGORITHM_CODE[selectedAlgorithm].getHighlightLine(currentStepData.type, currentStepData.message) : null}
                stepMessage={currentStepData?.message}
                stepType={currentStepData?.type}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Right: Knapsack visualization */}
        <motion.div
          layout
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className={showCode ? "xl:w-80 shrink-0" : "lg:col-span-2"}
        >
          <Card className="glass-panel h-full">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xs">Knapsack Visualization</CardTitle>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>Weight: <span className="font-mono text-foreground">{totalWeight}/{capacity}</span></span>
                  <span>Value: <span className="font-mono text-primary font-semibold">{totalValue}</span></span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-4 pt-0 space-y-4">
              {/* Capacity bar */}
              <div className="space-y-1.5">
                <div className="relative h-6 rounded-full overflow-hidden bg-muted/40 border border-white/10">
                  <motion.div
                    className="absolute inset-y-0 left-0 rounded-full"
                    style={{ background: `linear-gradient(90deg, ${ALGO_COLORS[selectedAlgorithm]}, ${ALGO_COLORS[selectedAlgorithm]}aa)` }}
                    initial={{ width: 0 }}
                    animate={{ width: `${fillPct}%` }}
                    transition={{ duration: 0.4, ease: "easeOut" }}
                  />
                  {fillPct > 15 && (
                    <div className="absolute inset-0 flex items-center justify-center text-xs font-mono font-semibold text-white mix-blend-difference">
                      {fillPct.toFixed(0)}%
                    </div>
                  )}
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0</span>
                  <span>Capacity: {capacity}</span>
                </div>
              </div>

              {/* Item blocks */}
              <div className="min-h-32 flex flex-wrap gap-2 content-start p-3 rounded-xl border border-white/5 bg-black/20">
                <AnimatePresence>
                  {items.map((item, i) => {
                    if (!displaySelected.has(i)) return null;
                    return (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, scale: 0.5, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.5 }}
                        transition={{ type: "spring", stiffness: 400, damping: 25 }}
                        className={cn(
                          "bg-gradient-to-br text-white rounded-lg flex flex-col items-center justify-center text-center p-2 border border-white/20",
                          ITEM_COLORS[i % ITEM_COLORS.length]
                        )}
                        style={{ width: `${Math.max(item.weight * 5, 52)}px`, height: `${Math.max(item.value * 1.2, 48)}px` }}
                        data-testid={`knapsack-item-${item.id}`}
                      >
                        <p className="text-[10px] font-bold leading-none text-center">{item.name.length > 7 ? item.name.slice(0, 6) + '…' : item.name}</p>
                        <p className="text-[10px] opacity-80 mt-0.5">V:{item.value}</p>
                      </motion.div>
                    );
                  })}
                  {displaySelected.size === 0 && (
                    <div className="w-full flex flex-col items-center justify-center py-6 text-center gap-2">
                      <span className="text-3xl">🎒</span>
                      <p className="text-xs text-muted-foreground">Press <span className="text-primary font-medium">Run</span> to fill the knapsack</p>
                      {!demoMode && <p className="text-[10px] text-muted-foreground">Or try <span className="text-amber-400 font-medium">Auto Demo</span> to watch all algorithms automatically</p>}
                    </div>
                  )}
                </AnimatePresence>
              </div>

              {/* Step message */}
              <AnimatePresence mode="wait">
                {currentStepData && (
                  <motion.div
                    key={currentStep}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/30 border border-white/5"
                  >
                    <ChevronRight className="w-3 h-3 text-primary flex-shrink-0" />
                    <span className="text-xs font-mono text-muted-foreground">{currentStepData.message}</span>
                    <Badge variant="secondary" className="ml-auto text-xs shrink-0">{currentStep + 1}/{result?.steps.length}</Badge>
                  </motion.div>
                )}
                {!currentStepData && result && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/10 border border-primary/20"
                  >
                    <span className="text-xs text-primary font-medium">
                      {currentStep === -1 ? `Ready — ${result.steps.length} steps recorded. Press Play to animate.` : `Complete — Optimal value: ${result.totalValue}`}
                    </span>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Playback controls */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <Card className="glass-panel">
          <CardContent className="p-4">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={handleReset} className="border-white/10 hover:bg-white/5 h-9 w-9" data-testid="btn-reset">
                  <RotateCcw className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={handleStepBack} disabled={currentStep <= -1} className="border-white/10 hover:bg-white/5 h-9 w-9" data-testid="btn-step-back">
                  <SkipBack className="w-4 h-4" />
                </Button>

                {playing ? (
                  <Button onClick={handlePause} className="bg-primary hover:bg-primary/90 glow-primary h-9 px-5" data-testid="btn-pause">
                    <Pause className="w-4 h-4 mr-2" />
                    Pause
                  </Button>
                ) : (
                  <Button onClick={handleStart} className="bg-primary hover:bg-primary/90 glow-primary h-9 px-5" data-testid="btn-play">
                    <Play className="w-4 h-4 mr-2" />
                    {result ? (currentStep >= (result.steps.length - 1) ? "Restart" : "Play") : "Run"}
                  </Button>
                )}

                <Button variant="outline" size="icon" onClick={handleStepForward} disabled={!result || currentStep >= result.steps.length - 1} className="border-white/10 hover:bg-white/5 h-9 w-9" data-testid="btn-step-forward">
                  <SkipForward className="w-4 h-4" />
                </Button>
              </div>

              {/* Progress */}
              {result && (
                <div className="flex items-center gap-3 flex-1 max-w-80">
                  <span className="text-xs text-muted-foreground font-mono w-16 text-right">{currentStep + 1}</span>
                  <div className="relative flex-1 h-1.5 rounded-full bg-muted/50">
                    <div
                      className="absolute inset-y-0 left-0 rounded-full transition-all"
                      style={{ width: `${((currentStep + 1) / result.steps.length) * 100}%`, background: ALGO_COLORS[selectedAlgorithm] }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground font-mono w-16">{result.steps.length}</span>
                </div>
              )}

              {/* Result badges */}
              {result && (
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className="text-xs border-primary/30 text-primary">Value: {result.totalValue}</Badge>
                  <Badge variant="outline" className="text-xs border-white/10 text-muted-foreground">Weight: {result.totalWeight}/{capacity}</Badge>
                  <Badge variant="outline" className="text-xs border-white/10 text-muted-foreground">{result.stepsCount} steps</Badge>
                  <Badge variant="outline" className="text-xs border-white/10 text-muted-foreground">{result.timeMs.toFixed(3)}ms</Badge>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Item Editor modal */}
      <ItemEditor open={showItemEditor} onClose={() => setShowItemEditor(false)} />

      {/* DP Table */}
      {showDPTable && selectedAlgorithm === "dp" && result && (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
          <Card className="glass-panel overflow-hidden">
            <CardHeader className="pb-2 flex flex-row items-center justify-between">
              <CardTitle className="text-xs">DP Table <span className="text-muted-foreground font-normal">(rows = items, cols = capacity 0..{dpTableCols})</span></CardTitle>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <div className="w-2.5 h-2.5 rounded-sm bg-primary/50" />
                <span>Current cell</span>
              </div>
            </CardHeader>
            <CardContent className="p-3 pt-0 overflow-x-auto">
              <DPTable items={items} capacity={capacity} result={result} currentStep={currentStep} dpTableCols={dpTableCols} highlight={dpHighlightCell} />
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}

function DPTable({ items, capacity, result, currentStep, dpTableCols, highlight }: {
  items: { id: number; name: string; weight: number; value: number }[];
  capacity: number;
  result: KnapsackResult;
  currentStep: number;
  dpTableCols: number;
  highlight: { row?: number; col?: number } | null;
}) {
  // Reconstruct dp table up to currentStep
  const n = items.length;
  const dp: number[][] = Array(n + 1).fill(0).map(() => Array(dpTableCols + 1).fill(0));
  let stepsApplied = 0;

  for (let i = 0; i <= currentStep && i < result.steps.length; i++) {
    const s = result.steps[i];
    if (s.type === "fill-cell" && s.itemIndex !== undefined && s.capacity !== undefined && s.value !== undefined) {
      if (s.itemIndex <= n && s.capacity <= dpTableCols) {
        dp[s.itemIndex][s.capacity] = s.value;
        stepsApplied++;
      }
    }
  }

  return (
    <table className="text-xs border-collapse min-w-0">
      <thead>
        <tr>
          <th className="px-2 py-1 text-muted-foreground font-normal border border-white/5 bg-muted/20 text-left">Item \ W</th>
          {Array.from({ length: dpTableCols + 1 }, (_, c) => (
            <th key={c} className="px-2 py-1 text-muted-foreground font-mono font-normal border border-white/5 bg-muted/20 text-center">{c}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {Array.from({ length: n + 1 }, (_, row) => (
          <tr key={row}>
            <td className="px-2 py-1 border border-white/5 bg-muted/10 text-muted-foreground font-medium">
              {row === 0 ? "∅" : (() => { const n = items[row - 1]?.name ?? `${row}`; return n.length > 5 ? n.slice(0, 4) + '…' : n; })()}
            </td>
            {Array.from({ length: dpTableCols + 1 }, (_, col) => {
              const isHighlight = highlight?.row === row && highlight?.col === col;
              const val = dp[row][col];
              return (
                <motion.td
                  key={col}
                  className={cn(
                    "px-2 py-1 border border-white/5 text-center font-mono transition-colors duration-200",
                    isHighlight ? "bg-primary/30 text-primary font-bold" : val > 0 ? "bg-white/3 text-foreground" : "text-white/20"
                  )}
                  animate={isHighlight ? { scale: [1, 1.08, 1] } : {}}
                  transition={{ duration: 0.3 }}
                >
                  {val || "·"}
                </motion.td>
              );
            })}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
