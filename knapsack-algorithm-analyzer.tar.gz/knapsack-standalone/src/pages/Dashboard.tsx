import { motion } from "framer-motion";
import { Zap, TrendingUp, Clock, Package, Activity, ArrowRight } from "lucide-react";
import { MetricCard } from "@/components/MetricCard";
import { CounterAnimation } from "@/components/CounterAnimation";
import { useAppContext } from "@/contexts/AppContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { runDP } from "@/lib/algorithms";
import { useMemo } from "react";

const ALGORITHM_COLORS: Record<string, string> = {
  dp: "hsl(263, 90%, 65%)",
  greedy: "hsl(190, 100%, 50%)",
  backtracking: "hsl(45, 93%, 58%)",
  "branch-bound": "hsl(213, 100%, 60%)",
};

const ALGORITHM_LABELS: Record<string, string> = {
  dp: "Dynamic Programming",
  greedy: "Greedy",
  backtracking: "Backtracking",
  "branch-bound": "Branch & Bound",
};

const chartData = [
  { n: 4, dp: 0.01, greedy: 0.002, backtracking: 0.03, bb: 0.02 },
  { n: 6, dp: 0.02, greedy: 0.003, backtracking: 0.15, bb: 0.08 },
  { n: 8, dp: 0.04, greedy: 0.004, backtracking: 0.7, bb: 0.25 },
  { n: 10, dp: 0.08, greedy: 0.005, backtracking: 3.2, bb: 0.6 },
  { n: 12, dp: 0.14, greedy: 0.006, backtracking: 14, bb: 1.8 },
  { n: 15, dp: 0.22, greedy: 0.008, backtracking: 120, bb: 5.5 },
];

export default function Dashboard() {
  const { items, capacity, runHistory } = useAppContext();
  const [, setLocation] = useLocation();

  const latestResult = useMemo(() => runDP(items, capacity), [items, capacity]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.08 } },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-br from-primary/20 via-card to-accent/10 p-8"
      >
        <div className="absolute -top-20 -right-20 w-64 h-64 bg-primary/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-secondary/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-3">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-primary/20 text-primary border border-primary/30">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              Live Analysis
            </span>
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-gradient mb-2">
            Knapsack Algorithm Analyzer
          </h1>
          <p className="text-muted-foreground max-w-xl text-base">
            Visualize, benchmark, and compare knapsack algorithms in real-time. From dynamic programming to branch &amp; bound.
          </p>
          <div className="mt-6 flex gap-3">
            <Button
              onClick={() => setLocation("/visualizer")}
              className="bg-primary hover:bg-primary/90 text-primary-foreground glow-primary"
              data-testid="btn-launch-visualizer"
            >
              <Zap className="w-4 h-4 mr-2" />
              Launch Visualizer
            </Button>
            <Button
              variant="outline"
              onClick={() => setLocation("/benchmark")}
              className="border-white/10 text-foreground hover:bg-white/5"
              data-testid="btn-run-benchmark"
            >
              Run Benchmark
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </motion.div>

      {/* What is Knapsack? explainer */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}>
        <Card className="glass-panel border-white/8 overflow-hidden">
          <CardContent className="p-0">
            <div className="grid grid-cols-1 lg:grid-cols-5">
              {/* Left: problem statement */}
              <div className="lg:col-span-2 p-5 border-b lg:border-b-0 lg:border-r border-white/8">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-lg">🎒</span>
                  <span className="text-sm font-bold text-foreground">The Knapsack Problem</span>
                  <Badge className="text-[10px] bg-primary/20 text-primary border-primary/30">Classic CS</Badge>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  You have a bag with a <span className="text-foreground font-medium">weight limit</span>. Given a set of items — each with a weight and value — which items do you pack to <span className="text-primary font-medium">maximise total value</span> without exceeding the limit?
                </p>
                <div className="mt-4 p-3 rounded-lg bg-primary/8 border border-primary/15">
                  <p className="text-[11px] font-mono text-muted-foreground">
                    Capacity = <span className="text-primary">10 kg</span><br />
                    Item A: 6 kg → $7 &nbsp;&nbsp; Item B: 4 kg → $5 &nbsp;&nbsp; Item C: 3 kg → $4
                  </p>
                  <p className="text-[11px] text-muted-foreground mt-2">Best pick: <span className="text-emerald-400 font-medium">B + C = 7 kg, $9</span> — not the heaviest, not the most valuable, but optimal!</p>
                </div>
              </div>
              {/* Middle: why hard */}
              <div className="lg:col-span-2 p-5 border-b lg:border-b-0 lg:border-r border-white/8">
                <p className="text-xs font-semibold text-foreground mb-3">Why is it hard?</p>
                <div className="space-y-2">
                  {[
                    { icon: "💥", label: "2ⁿ combinations", desc: "With 20 items there are over 1 million possible subsets to check" },
                    { icon: "🧩", label: "No simple formula", desc: "You can't just sort by value or weight — combinations matter" },
                    { icon: "🌍", label: "NP-Complete", desc: "No known algorithm solves it fast for all inputs — yet it's everywhere in real life" },
                  ].map(item => (
                    <div key={item.label} className="flex gap-2.5 text-xs">
                      <span className="text-base shrink-0 mt-0.5">{item.icon}</span>
                      <div>
                        <span className="font-medium text-foreground">{item.label} — </span>
                        <span className="text-muted-foreground">{item.desc}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              {/* Right: real-world uses */}
              <div className="p-5">
                <p className="text-xs font-semibold text-foreground mb-3">Real-world uses</p>
                <div className="space-y-1.5">
                  {[
                    { icon: "📦", text: "Logistics & delivery routing" },
                    { icon: "💰", text: "Portfolio investment allocation" },
                    { icon: "☁️", text: "Cloud resource scheduling" },
                    { icon: "🔒", text: "Cryptography (subset-sum)" },
                    { icon: "🎮", text: "Game inventory systems" },
                    { icon: "🛰️", text: "Satellite bandwidth packing" },
                  ].map(item => (
                    <div key={item.text} className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{item.icon}</span>
                      {item.text}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Optimal Value"
          value={<CounterAnimation value={latestResult.totalValue} />}
          icon={TrendingUp}
          description="from DP algorithm"
          trend={{ value: "+12%", positive: true }}
          delay={0.1}
        />
        <MetricCard
          title="Items Evaluated"
          value={<CounterAnimation value={items.length} />}
          icon={Package}
          description={`capacity: ${capacity}`}
          delay={0.15}
        />
        <MetricCard
          title="DP Steps"
          value={<CounterAnimation value={latestResult.stepsCount} />}
          icon={Activity}
          description="table cells filled"
          delay={0.2}
        />
        <MetricCard
          title="Exec Time"
          value={<CounterAnimation value={Number(latestResult.timeMs.toFixed(3))} format={(v) => `${v.toFixed(2)}ms`} />}
          icon={Clock}
          description="dynamic programming"
          delay={0.25}
        />
      </div>

      {/* Chart + Recent Runs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="lg:col-span-2"
        >
          <Card className="glass-panel h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Runtime Comparison</CardTitle>
              <p className="text-xs text-muted-foreground">Execution time vs problem size (ms)</p>
            </CardHeader>
            <CardContent className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 4, right: 12, bottom: 0, left: -20 }}>
                  <defs>
                    <linearGradient id="dpGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={ALGORITHM_COLORS.dp} stopOpacity={0.3} />
                      <stop offset="95%" stopColor={ALGORITHM_COLORS.dp} stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="greedyGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={ALGORITHM_COLORS.greedy} stopOpacity={0.3} />
                      <stop offset="95%" stopColor={ALGORITHM_COLORS.greedy} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="n" tick={{ fill: "hsl(215 20% 55%)", fontSize: 11 }} tickLine={false} axisLine={false} label={{ value: "n items", position: "insideBottom", fill: "hsl(215 20% 55%)", fontSize: 11, dy: 12 }} />
                  <YAxis tick={{ fill: "hsl(215 20% 55%)", fontSize: 11 }} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{ background: "hsl(215 40% 9%)", border: "1px solid hsl(215 30% 15%)", borderRadius: 8, fontSize: 12 }}
                    labelStyle={{ color: "hsl(210 40% 95%)" }}
                    formatter={(v: number) => [`${v}ms`]}
                  />
                  <Area type="monotone" dataKey="dp" stroke={ALGORITHM_COLORS.dp} fill="url(#dpGrad)" strokeWidth={2} name="DP" dot={false} />
                  <Area type="monotone" dataKey="greedy" stroke={ALGORITHM_COLORS.greedy} fill="url(#greedyGrad)" strokeWidth={2} name="Greedy" dot={false} />
                  <Area type="monotone" dataKey="bb" stroke={ALGORITHM_COLORS.backtracking} fill="none" strokeWidth={1.5} strokeDasharray="4 4" name="B&B" dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.35 }}
        >
          <Card className="glass-panel h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold">Recent Runs</CardTitle>
            </CardHeader>
            <CardContent>
              {runHistory.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center mb-3">
                    <Activity className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground">No runs yet</p>
                  <p className="text-xs text-muted-foreground mt-1">Run an algorithm to see history</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {runHistory.slice(0, 6).map((entry) => (
                    <div key={entry.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-white/5 transition-colors" data-testid={`history-entry-${entry.id}`}>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{ background: ALGORITHM_COLORS[entry.algorithm] }} />
                        <span className="text-xs font-medium text-foreground">{ALGORITHM_LABELS[entry.algorithm]}</span>
                      </div>
                      <Badge variant="secondary" className="text-xs font-mono">
                        {entry.result.totalValue}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Algorithm Quickview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-base font-semibold">Algorithm Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { key: "dp", label: "Dynamic Programming", complexity: "O(n·W)", space: "O(n·W)", optimal: true },
                { key: "greedy", label: "Greedy", complexity: "O(n log n)", space: "O(n)", optimal: false },
                { key: "backtracking", label: "Backtracking", complexity: "O(2ⁿ)", space: "O(n)", optimal: true },
                { key: "branch-bound", label: "Branch & Bound", complexity: "O(2ⁿ) best-case", space: "O(n)", optimal: true },
              ].map((algo) => (
                <div key={algo.key} className="p-4 rounded-xl border border-white/5 bg-white/2 hover:bg-white/5 transition-colors group cursor-pointer" data-testid={`algo-card-${algo.key}`}>
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-3 h-3 rounded-full" style={{ background: ALGORITHM_COLORS[algo.key] }} />
                    <span className="text-xs font-semibold text-foreground">{algo.label}</span>
                  </div>
                  <div className="space-y-1.5 text-xs text-muted-foreground">
                    <div className="flex items-center justify-between">
                      <span>Time</span>
                      <span className="font-mono text-foreground">{algo.complexity}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Space</span>
                      <span className="font-mono text-foreground">{algo.space}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Optimal</span>
                      <Badge variant={algo.optimal ? "default" : "secondary"} className="text-xs h-4 px-1.5" style={algo.optimal ? { background: ALGORITHM_COLORS[algo.key] + "33", color: ALGORITHM_COLORS[algo.key], border: "1px solid " + ALGORITHM_COLORS[algo.key] + "66" } : {}}>
                        {algo.optimal ? "Yes" : "No"}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
