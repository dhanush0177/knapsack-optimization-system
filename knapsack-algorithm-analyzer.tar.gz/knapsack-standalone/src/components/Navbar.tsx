import React from 'react';
import { Bell, Search, User } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useLocation } from 'wouter';

export function Navbar() {
  const [location] = useLocation();

  const getPageTitle = () => {
    switch (location) {
      case '/': return 'Dashboard';
      case '/visualizer': return 'Algorithm Visualizer';
      case '/benchmark': return 'Benchmarking';
      case '/analytics': return 'Performance Analytics';
      case '/compare': return 'Complexity Comparison';
      case '/reports': return 'Reports';
      case '/settings': return 'Settings';
      default: return '';
    }
  };

  return (
    <header className="h-16 border-b border-border bg-background/80 backdrop-blur-md sticky top-0 z-10 flex items-center justify-between px-6 shrink-0">
      <div className="flex items-center gap-4">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          {getPageTitle()}
        </h1>
        <div className="h-4 w-px bg-border hidden md:block"></div>
        <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground">
          <span>Knapsack Analyzer</span>
          <span>/</span>
          <span className="text-foreground">{getPageTitle()}</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative hidden sm:block">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input 
            placeholder="Search commands (Cmd+K)" 
            className="pl-9 w-64 bg-muted/50 border-transparent focus-visible:ring-primary focus-visible:bg-background h-9 rounded-full"
          />
        </div>
        
        <Button variant="ghost" size="icon" className="relative rounded-full text-muted-foreground hover:text-foreground">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-primary animate-pulse glow-primary"></span>
        </Button>
        
        <Avatar className="h-9 w-9 border border-primary/20 ring-2 ring-background cursor-pointer">
          <AvatarFallback className="bg-primary/10 text-primary font-medium">CS</AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
}
