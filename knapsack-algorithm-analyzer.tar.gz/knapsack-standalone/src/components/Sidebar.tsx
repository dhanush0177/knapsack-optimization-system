import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  Play, 
  BarChart2, 
  Activity, 
  ListTree, 
  FileText, 
  Settings,
  ChevronLeft,
  ChevronRight,
  Hexagon,
  Zap
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface SidebarProps {
  collapsed: boolean;
  setCollapsed: (v: boolean) => void;
}

const routes = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/visualizer', label: 'Algorithm Visualizer', icon: Play },
  { path: '/benchmark', label: 'Benchmarking', icon: Activity },
  { path: '/analytics', label: 'Performance', icon: BarChart2 },
  { path: '/compare', label: 'Complexity', icon: ListTree },
  { path: '/greedy', label: 'Greedy Analysis', icon: Zap },
  { path: '/reports', label: 'Reports', icon: FileText },
  { path: '/settings', label: 'Settings', icon: Settings },
];

export function Sidebar({ collapsed, setCollapsed }: SidebarProps) {
  const [location] = useLocation();

  return (
    <motion.aside
      initial={false}
      animate={{ width: collapsed ? 80 : 260 }}
      className="h-screen bg-sidebar border-r border-sidebar-border relative flex flex-col z-20 transition-all duration-300 ease-in-out"
    >
      <div className="p-4 flex items-center justify-between border-b border-sidebar-border h-16 shrink-0">
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-2 overflow-hidden"
          >
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center glow-primary">
              <Hexagon className="w-5 h-5 text-primary" />
            </div>
            <span className="font-bold text-lg tracking-tight text-gradient whitespace-nowrap">
              KnapAnalyzer
            </span>
          </motion.div>
        )}
        {collapsed && (
          <div className="w-full flex justify-center">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <Hexagon className="w-5 h-5 text-primary" />
            </div>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto py-6 px-3 space-y-1">
        {routes.map((route) => {
          const isActive = location === route.path;
          return (
            <Link key={route.path} href={route.path}>
              <div
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-all duration-200 group relative",
                  isActive 
                    ? "bg-primary/10 text-primary font-medium" 
                    : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                  collapsed && "justify-center px-0"
                )}
                data-testid={`nav-${route.label.toLowerCase().replace(' ', '-')}`}
              >
                {isActive && (
                  <motion.div 
                    layoutId="active-nav"
                    className="absolute inset-0 bg-primary/10 rounded-lg border border-primary/20"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <route.icon className={cn(
                  "w-5 h-5 shrink-0 z-10 transition-colors",
                  isActive ? "text-primary glow-primary" : "text-muted-foreground group-hover:text-foreground"
                )} />
                {!collapsed && (
                  <span className="z-10 whitespace-nowrap">{route.label}</span>
                )}
              </div>
            </Link>
          );
        })}
      </div>

      <div className="p-4 border-t border-sidebar-border shrink-0">
        <Button
          variant="ghost"
          size="icon"
          className="w-full h-10 flex items-center justify-center text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"
          onClick={() => setCollapsed(!collapsed)}
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </Button>
      </div>
    </motion.aside>
  );
}
