import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: React.ReactNode;
  icon: LucideIcon;
  description?: string;
  trend?: {
    value: string;
    positive?: boolean;
  };
  delay?: number;
  className?: string;
}

export function MetricCard({ title, value, icon: Icon, description, trend, delay = 0, className }: MetricCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      <Card className={`glass-panel overflow-hidden relative ${className}`}>
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="space-y-1">
              <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
              <div className="text-3xl font-bold tracking-tight font-mono text-foreground">
                {value}
              </div>
            </div>
            <div className="p-2 bg-primary/10 rounded-lg">
              <Icon className="w-5 h-5 text-primary" />
            </div>
          </div>
          
          {(description || trend) && (
            <div className="flex items-center text-xs">
              {trend && (
                <span className={`font-medium mr-2 ${trend.positive ? 'text-success' : 'text-danger'}`}>
                  {trend.value}
                </span>
              )}
              {description && (
                <span className="text-muted-foreground">{description}</span>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
